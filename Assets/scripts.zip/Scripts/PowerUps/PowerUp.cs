using UnityEngine;

public abstract class PowerUp : ScriptableObject
{
    public string title;
    public Sprite icon;
    public abstract void Apply(GameManager gm, Player player);
}
