using UnityEngine;
using System;

public class TurnSystem : MonoBehaviour
{
    public static TurnSystem Instance { get; private set; }

    private void Awake() => Instance = this;

    // ------- internes Zug-Tracking -------------------------
    public (Vector2Int from, Vector2Int to, ChessPiece piece) LastMove => lastMove;
    private (Vector2Int from, Vector2Int to, ChessPiece piece) lastMove;

    private int moveCounter;
    public event Action<int> OnFiveMoves;   // feuert nach jedem 5. Zug

    // --------------------------------------------------------
    public void RegisterMove(Vector2Int from, Vector2Int to, ChessPiece piece)
    {
        lastMove = (from, to, piece);

        moveCounter++;
        if (moveCounter % 5 == 0)
            OnFiveMoves?.Invoke(moveCounter / 5);
    }

    // --------------------------------------------------------
    /// <summary>
    /// Prüft, ob für einen Bauernzug <paramref name="myFrom"/> → <paramref name="myTo"/>
    /// ein En-Passant-Schlagen möglich ist.
    /// </summary>
    public bool CanEnPassant(Vector2Int myFrom, Vector2Int myTo, Player me)
    {
        if (lastMove.piece is not Pawn) return false;

        int dir         = me == Player.White ? 1 : -1;
        bool onCorrectRank = me == Player.White ? myFrom.y == 4 : myFrom.y == 3;

        return onCorrectRank &&
               // Gegnerischer Bauer hat Doppelschritt gemacht:
               Mathf.Abs(lastMove.from.y - lastMove.to.y) == 2 &&
               // Landet unmittelbar neben unserem Bauern:
               lastMove.to.y == myFrom.y &&
               lastMove.to.x == myTo.x &&
               lastMove.piece.Owner != me;
    }
}

