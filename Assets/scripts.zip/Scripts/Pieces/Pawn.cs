using UnityEngine;
using System.Collections.Generic;

public class Pawn : ChessPiece
{
    public bool canMoveBackwards;

	public override List<Vector2Int> GetBaseMoves(Board board)
	{
		var m   = new List<Vector2Int>();
		int dir = Owner == Player.White ? 1 : -1;
		var fwd = BoardPos + new Vector2Int(0, dir);

		// 1. Ein Feld vorwärts
		if (board.IsEmpty(fwd)) m.Add(fwd);

		// 2. Doppelschritt – nur wenn Startreihe & beide Felder frei
		bool atStart = Owner == Player.White ? BoardPos.y == 1 : BoardPos.y == 6;
		var fwd2 = BoardPos + new Vector2Int(0, 2 * dir);
		if (atStart && board.IsEmpty(fwd) && board.IsEmpty(fwd2))
			m.Add(fwd2);

		// 3. Diagonal schlagen (links + rechts)
		Vector2Int[] diag = { new(-1, dir), new(1, dir) };
		foreach (var d in diag)
		{
			var p = BoardPos + d;
			if (!board.InBounds(p)) continue;

			// normales Capture
			if (board.IsEnemy(p, Owner)) m.Add(p);

			// En Passant
			if (TurnSystem.Instance.CanEnPassant(BoardPos, p, Owner))
				m.Add(p);
		}

		return m;
	}
}
