using UnityEngine;
using UnityEngine.UI;

public class PowerUpPanel : MonoBehaviour
{
    [SerializeField] private Button leftBtn, rightBtn;
    [SerializeField] private Image leftIcon, rightIcon;
    private PowerUp left, right;
    private Player current;

    public void Show(PowerUp a, PowerUp b, Player player)
    {
        left = a; right = b; current = player;
        leftIcon.sprite = a.icon;
        rightIcon.sprite = b.icon;
        gameObject.SetActive(true);
    }

    private void Awake()
    {
        leftBtn.onClick.AddListener(() => Select(left));
        rightBtn.onClick.AddListener(() => Select(right));
    }

    private void Select(PowerUp pick)
    {
        pick.Apply(GameManager.Instance, current);
        gameObject.SetActive(false);
    }
}
