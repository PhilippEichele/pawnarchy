using UnityEngine;

public class SquareHighlight : MonoBehaviour
{
    public void Flash() { /*…*/ }
}
